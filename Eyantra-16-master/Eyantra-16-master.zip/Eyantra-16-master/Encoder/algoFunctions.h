void updatePaths() {
	//
}