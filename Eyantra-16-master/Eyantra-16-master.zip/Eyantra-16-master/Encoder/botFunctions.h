void startBot() {
	//
}

void stopBot() {
	//
}

int obstacleDetect() {
	return 0;
}